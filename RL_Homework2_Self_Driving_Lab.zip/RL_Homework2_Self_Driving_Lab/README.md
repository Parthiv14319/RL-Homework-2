# RL Homework 2 — Self-Driving Lab Simulator

**Selected project:** Project 7 — Self-driving lab simulator  
**Algorithm:** Tabular Q-learning (one-step, single-state formulation)  
**Language:** Python

## Problem
An agent selects a temperature and concentration setting for a simulated reaction. It receives a reward equal to the simulated reaction yield and learns which setting gives the highest yield.

> This is a synthetic educational simulator. It does not represent a real chemical process and must not be used to set real laboratory conditions.

## Run locally
```bash
pip install -r requirements.txt
python src/main.py
```
The program prints the learned setting and saves:
- `results/learning_curve.png`
- `results/baseline_comparison.png`

## Formulation
- **State:** A single state representing the current experiment-selection decision.
- **Action:** One of 49 combinations of 7 temperature settings and 7 concentration settings.
- **Reward:** Simulated reaction yield from 0 to 100.
- **Environment:** A synthetic reaction-yield function with a broad optimum near temperature 75 and concentration 0.42, plus small random measurement noise.
- **Algorithm:** Epsilon-greedy tabular Q-learning. Exploration starts at 1.0 and decays to a floor of 0.05.

## Results from the included seeded run
- Random baseline mean yield: 20.64
- Q-learning mean yield over final 200 training episodes: 91.06
- Learned setting: temperature 70, concentration 0.4

The exact values are reproducible with the fixed random seeds and the included code. Training reward is measured while exploration is still occurring; the final-200 average is therefore a training-period metric, not a separate held-out test score.

## Repository contents
- `src/main.py` — simulator, Q-learning training, baseline and plotting
- `problem_formulation.pdf` — one-page formulation
- `project_report.pdf` — report and results
- `presentation/rl_homework2_slides.pptx` — five-slide presentation
- `results/` — generated plots

## Limitations and ethics
This simplified problem is a one-step decision task rather than a full sequential laboratory workflow. The reward landscape is hand-designed, not learned from experimental data. Real experiments require domain expertise, safety reviews, validated equipment, and careful handling of hazardous materials. The simulation should not be interpreted as scientific or medical advice.
