"""
RL Homework 2 - Project 7: Self-Driving Lab Simulator
A tabular Q-learning agent chooses temperature and concentration settings
to maximize the yield of a simulated chemical reaction.

This is an educational toy simulator, not a model of a real chemical process.
Run: python src/main.py
Dependencies: numpy, matplotlib
"""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

SEED = 42
EPISODES = 2500
MAX_STEPS = 1
ALPHA = 0.15
GAMMA = 0.0
EPSILON_START = 1.0
EPSILON_END = 0.05
EPSILON_DECAY = 0.995

# Discrete controllable settings (arbitrary educational units)
TEMPERATURES = np.array([40, 50, 60, 70, 80, 90, 100])
CONCENTRATIONS = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7])
ACTIONS = [(i, j) for i in range(len(TEMPERATURES))
                   for j in range(len(CONCENTRATIONS))]

def simulated_yield(temp, conc, rng):
    """Synthetic reaction-yield landscape with small measurement noise."""
    # Peak near 75 temperature units and concentration 0.4.
    temp_factor = np.exp(-((temp - 75.0) ** 2) / (2 * 13.0 ** 2))
    conc_factor = np.exp(-((conc - 0.42) ** 2) / (2 * 0.13 ** 2))
    interaction = 0.90 + 0.10 * np.exp(-((temp - 75.0) * (conc - 0.42))**2 / 100)
    noise = rng.normal(0, 0.012)
    return float(np.clip(100 * temp_factor * conc_factor * interaction / 0.98 + noise*100, 0, 100))

def train_q_learning(seed=SEED):
    rng = np.random.default_rng(seed)
    # One-step contextual bandit represented as a one-state Q-learning problem.
    q = np.zeros(len(ACTIONS), dtype=float)
    rewards = []
    eps = EPSILON_START
    for episode in range(EPISODES):
        if rng.random() < eps:
            action_idx = int(rng.integers(len(ACTIONS)))
        else:
            best = np.flatnonzero(q == q.max())
            action_idx = int(rng.choice(best))
        ti, ci = ACTIONS[action_idx]
        reward = simulated_yield(TEMPERATURES[ti], CONCENTRATIONS[ci], rng)
        q[action_idx] += ALPHA * (reward - q[action_idx])
        rewards.append(reward)
        eps = max(EPSILON_END, eps * EPSILON_DECAY)
    return q, np.asarray(rewards)

def evaluate_random(seed=123, n=EPISODES):
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n):
        idx = int(rng.integers(len(ACTIONS)))
        ti, ci = ACTIONS[idx]
        vals.append(simulated_yield(TEMPERATURES[ti], CONCENTRATIONS[ci], rng))
    return np.asarray(vals)

def moving_average(x, window=100):
    return np.convolve(x, np.ones(window)/window, mode="valid")

def main():
    root = Path(__file__).resolve().parents[1]
    out = root / "results"
    out.mkdir(exist_ok=True)
    q, train_rewards = train_q_learning()
    random_rewards = evaluate_random()
    best_idx = int(np.argmax(q))
    ti, ci = ACTIONS[best_idx]
    best_temp, best_conc = TEMPERATURES[ti], CONCENTRATIONS[ci]

    plt.figure(figsize=(9, 5))
    plt.plot(moving_average(train_rewards), label="Q-learning (100-episode moving average)")
    plt.plot(moving_average(random_rewards), label="Random baseline (100-episode moving average)")
    plt.xlabel("Episode")
    plt.ylabel("Simulated reaction yield")
    plt.title("Learning curve: Q-learning vs random baseline")
    plt.legend()
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(out / "learning_curve.png", dpi=180)
    plt.close()

    plt.figure(figsize=(8, 5))
    plt.bar(["Random baseline", "Q-learning\n(last 200 episodes)"],
            [random_rewards.mean(), train_rewards[-200:].mean()])
    plt.ylabel("Average simulated yield")
    plt.title("Average yield comparison")
    plt.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(out / "baseline_comparison.png", dpi=180)
    plt.close()

    print(f"Best learned setting: temperature={best_temp}, concentration={best_conc:.1f}")
    print(f"Random baseline mean yield: {random_rewards.mean():.2f}")
    print(f"Q-learning final-200 mean yield: {train_rewards[-200:].mean():.2f}")
    print("Graphs saved in results/")

if __name__ == "__main__":
    main()
